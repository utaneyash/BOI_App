function Nav() {
  return (
    <nav>
      <div className="brand">
        <span className="brand-mark">£</span>
        Ledgr
      </div>
      <div className="nav-links">
        <a href="#features">Features</a>
        <a href="#trust">Security</a>
        <a href="#">Pricing</a>
        <a href="#">Support</a>
      </div>
      <a href="#" className="nav-cta">Open account</a>
    </nav>
  );
}

export default Nav;
