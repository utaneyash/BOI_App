function Footer() {
  return (
    <footer>
      <div className="brand" style={{ fontSize: '16px' }}>
        <span className="brand-mark" style={{ width: '22px', height: '22px', fontSize: '10px' }}>£</span>
        Ledgr
      </div>
      <div className="foot-links">
        <a href="#">Privacy</a>
        <a href="#">Terms</a>
        <a href="#">Security</a>
        <a href="#">Contact</a>
      </div>
      <div>© 2026 Ledgr, Inc.</div>
    </footer>
  );
}

export default Footer;
