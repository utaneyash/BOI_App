import LandingPage from './pages/LandingPage.jsx';

function App() {
  // Once you add React Router, this is where <Routes> would live,
  // e.g. "/" -> LandingPage, "/login" -> LoginPage, "/dashboard" -> Dashboard
  return <LandingPage />;
}

export default App;
