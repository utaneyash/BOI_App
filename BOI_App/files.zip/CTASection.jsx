function CTASection() {
  return (
    <section className="cta-section">
      <div className="guilloche" style={{ opacity: 0.1 }}></div>
      <div className="cta-title">Open an account in under four minutes.</div>
      <p className="cta-sub">
        No paperwork, no branch visit — just your ID and a few details about you.
      </p>
      <button className="btn-primary">Get started</button>
    </section>
  );
}

export default CTASection;
